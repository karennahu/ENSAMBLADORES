package EnsmbladorProyecto;

import java.awt.Dimension;
import java.awt.Toolkit;

public class DimensionesPantalla {
	
	private int ancho;
	private int alto;
	
	public void obtenerTamanio(){
		Toolkit tk = Toolkit.getDefaultToolkit();
		Dimension t = tk.getScreenSize();
		this.ancho = (int) t.getWidth();
		this.alto = (int) t.getHeight();
	}
	
	
	
	public int getAncho() {
		return ancho;
	}



	public void setAncho(int ancho) {
		this.ancho = ancho;
	}



	public int getAlto() {
		return alto;
	}



	public void setAlto(int alto) {
		this.alto = alto;
	}


}

