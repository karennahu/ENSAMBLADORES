package EnsmbladorProyecto;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Formatter;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.w3c.dom.CDATASection;

public class VentanaSepararElem extends JFrame implements ActionListener {
    String[] codSep = new String[100];   
    DefaultTableModel modeloAux = new DefaultTableModel(null, new Object[] {"Token", "Valor"});
    JTable tabla;
    int limSuperior=0;
    int indV, indT;
	private JTextField renglones;
	private JLabel totLineas;
	JTextArea txt;
    public String rutanueva="C:\\Users\\Public\\archivo1.txt";  // ARCHIVO CON CODIGO LIMPIO
    String ArchSeparado="C:\\Users\\Public\\archivo2.txt";		
    
    public VentanaSepararElem(String[] lineas, int cont) {//VECTOR LINEAS TIENE EL CODIGO DIVIDIDO EN SECCIONES DE 20            
            ArrayList<String> codigo = new ArrayList<String>();          
    	    String CodigoComp="";  // VARIABLE PARA METER EL CODIGO COMPLETO         			
		    this.setTitle("Ventana separa e identifica elementos");   // TITULO DE LA VENTANA
			this.setResizable(false);  //PARA QUE NO SE PUEDA CAMBIAR EL TAMA�O DE LA VENTANA EN EJECUCION		  
	     	this.setContentPane(getPanel());  // AGREGAS EL PANEL A LA VENTANA						  
	     	for(String cad: lineas) {  // METE EN UN SOLO STRING EL CODIGO DEL VECTOR
		    	if(cad != null) {
		    		CodigoComp =  CodigoComp + cad;	
		    		//System.out.println(CodigoComp);
		    	}
		    }	     	
	 //************************************************************************************* 
	        divideV(ArchSeparado); // PARA DIVIDiR EN EL VECTOR GLOBAL CODSEP PAQUETES DE 20 INEAS   
      // ***********************   CALCLULA LIMITE SUPERIOR DEL VECTOR ********************************************* 
	        for(int i =0; i<100;i++) {
	        	if(codSep[i]!= null) {
	        		codigo.add(codSep[i]);
	        	}
	        }
	        limSuperior = codigo.size(); 
	        System.out.println(limSuperior);
   // ***********************************************************************************************************                
			renglones.setText(" Linea: 0 - 20");
		    totLineas.setText("Total de lineas: " + cont);
		    indV=0;
	        txt.setText(codSep[indV]);		                
			this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);	  	
    }
	
    
    	public void divideV(String ruta) {
    	   String cad = "";	  
    	   int contL = 0;
    	   int indV= 0;
 		   try {
 			   FileReader arch = new FileReader(ruta);
 			   BufferedReader br = new BufferedReader(arch);
 			   String linea="";			   
 			   while((linea = br.readLine()) != null) { 				   
 			   		contL =  contL + 1;
			   		//if(contL == 1) {
			   		// cad = linea;	
			   		//}else {
 			   		 cad = cad +"\n"+ linea;
			   		//}
 			   		if(contL%20 == 0) {
 			   			codSep[indV] = cad;
 			   			//System.out.println(codSep[indV]);
 			   			cad = "";
 			   			indV = indV+1;
 			   		} 					 	  				  		   
 			   }
	   		  codSep[indV] = cad;
	   		//  System.out.println(codSep[indV]);
 			  arch.close();
 			  br.close();		   
 		   }catch(Exception e){
 			   	 JOptionPane.showMessageDialog(null, "Error");
 		   }	
    	}
    
	
	public JPanel getPanel() {
		JPanel panel = new JPanel();
		panel.setLayout(null);

        JLabel etq = new JLabel("Elementos Separados");
        etq.setBounds(35,4,350,34);
        etq.setFont(new Font("arial", 3,16));
        panel.add(etq);      
        
        JLabel etqr = new JLabel("Elementos identificados");
        etqr.setBounds(400,4,350,34);
        etqr.setFont(new Font("arial", 3,16));
        panel.add(etqr);  
        
                JButton btnAnterior = new JButton();
		btnAnterior.setBounds(340,490,40,35);
		ImageIcon imgAnt = new ImageIcon("src/ant.png");
		btnAnterior.setIcon(new ImageIcon(imgAnt.getImage().getScaledInstance(btnAnterior.getWidth(),
				btnAnterior.getHeight(),Image.SCALE_SMOOTH)));
		btnAnterior.addActionListener(this);
		btnAnterior.setActionCommand("anterior");
		panel.add(btnAnterior);
		
		JButton btnSiguiente = new JButton();
		btnSiguiente.setBounds(430,490,40,35);
		ImageIcon imgSig = new ImageIcon("src/sig.png");
		btnSiguiente.setIcon(new ImageIcon(imgSig.getImage().getScaledInstance(btnSiguiente.getWidth(),
				btnSiguiente.getHeight(),Image.SCALE_SMOOTH)));
		btnSiguiente.addActionListener(this);
		btnSiguiente.setActionCommand("siguiente");
		panel.add(btnSiguiente);
		
		renglones = new JTextField();
		renglones.setBounds(15,490,200,35);
		renglones.setEditable(false);
                panel.add(renglones);
        
            totLineas = new JLabel();
	    totLineas.setBounds(580,475,180,60);
	    totLineas.setFont(new Font("arial", 3,12));
	    panel.add(totLineas);

		txt = new JTextArea();
		txt.setBounds(15,50,200,420);
		txt.setEditable(false);
		JScrollPane scroll = new JScrollPane(txt);
		scroll.setBounds(15, 50, 200, 420);
                scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);		
                panel.add(scroll);
	    	    
                indT=1;
                modeloAux = IdentificaTodo(indT);	
	    
                tabla = new JTable();
                tabla.setModel(modeloAux);
	    
	    JScrollPane scrollx = null;
	    tabla.setBounds(250,50,500,420);
	    tabla.setFont(new Font("Arial",0,14));
		tabla.setBackground(new Color(hex("E0F8F7")));
		tabla.setEnabled(true);
		scrollx = new JScrollPane(tabla);
		scrollx.setBounds(250,50,500,420);
	    scrollx.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	    scrollx.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);		

	    panel.add(scrollx);     
		return panel;
	}

	
	public static DefaultTableModel IdentificaTodo(int limiteSup) {  
		int contLineas = 0;			
		int limiteInf = ((limiteSup*20)-20)+1;			
		limiteSup = limiteSup * 20;						    
		DefaultTableModel modeloAux = new DefaultTableModel(null, new Object[] {"Token", "Valor"});	
	    String[] registros = new String[2];	    	
	    
		try {
			FileReader arch = new FileReader("C:\\Users\\Public\\archivo2.txt");
			BufferedReader br = new BufferedReader(arch);
			String linea;			
			while((linea = br.readLine()) != null){	
				
			  contLineas = contLineas + 1;	
			  
		      if(contLineas == limiteInf) {	
		    	  
				if((linea.matches("^\".*\"$"))||linea.matches("^\'.*\'$")) {
					registros[0] = linea;
					registros[1] = "Constante Caracter";
					modeloAux.addRow(registros);
				}else if(linea.toUpperCase().matches("^0[0-9A-F]+H$")) {
					registros[0] = linea;
					registros[1] = "Constante num�rica Hexadecimal";
					modeloAux.addRow(registros);
				}else if((linea.toUpperCase().matches("(0|1){8}B$"))||(linea.toUpperCase().matches("(0|1){16}B$"))||(linea.toUpperCase().matches("(0|1){32}B$"))||(linea.toUpperCase().matches("(0|1){64}B$"))) {
					registros[0] = linea;
					registros[1] = "Constante num�rica Binaria";
					modeloAux.addRow(registros);
				}else if(linea.toUpperCase().matches("[0-9]+")) {
					registros[0] = linea;
					registros[1] = "Constante numerica Decimal";
					modeloAux.addRow(registros);
				}else if((linea.toUpperCase().matches("DUP\\('.*'\\)"))||(linea.toUpperCase().matches("DUP\\(\".*\"\\)"))||linea.toUpperCase().matches("DUP\\([0-9]+\\)")) {
					registros[0] = linea;
					registros[1] = "Pseudoinstrucci�n";
					modeloAux.addRow(registros);
				}else {
					switch(linea.toUpperCase()) {
					case "DATA SEGMENT":
					case "CODE SEGMENT":
					case "STACK SEGMENT":
					case "ENDS":
					case "DB":
					case "DW":
					case "EQU":
					case "BYTE PTR":
					case "WORD PTR":
					case "MACRO":
					case "ENDM":
					case "PROC":
					case "ENDP":
						registros[0] = linea;
						registros[1] = "Pseudoinstrucci�n";
						modeloAux.addRow(registros);
						break;
					case "CWD":
					case "PUSHA":
					case "STOSW":
					case "LDS":
					case "PUSH":
					case "MOV":
					case "SUB":
					case "JA":
					case "JNC":
					case "JNP":
					case "JNL":
						registros[0] = linea;
						registros[1] = "Instrucci�n";
						modeloAux.addRow(registros);
					    break;
					case "CDW":
                                        case "CLC":
                                        case "LODSB":
                                        case "LOSDW":
                                        case "STOSB":
                                        case "DIV":
                                        case "IMUL":
                                        case "INC":
                                        case "NEG":
                                        case "ADD":
                                        case "ROR":
                                        case "JNS":
                                        case "JS":
                                        case "LOOPNEJL":
                                        case "JG":
                                        case "JMP":
                                        case "JNBE":
                                       
					registros[0] = linea;
					registros[1] = "Simbolo";
					modeloAux.addRow(registros);
					break;
					case "AX":
					case "AH":
					case "AL":
					case "BX":
					case "BH":
					case "BL":
					case "CX":
					case "CH":
					case "CL":
					case "DX":
					case "DH":
					case "DL":
					case "SI":
					case "DI":
					case "SP":
					case "BP":
					case "SS":
					case "CS":
					case "DS":
					case "ES":
						registros[0] = linea;
						registros[1] = "Registro";
						modeloAux.addRow(registros);
					    break;
					default:
						if(linea.length()<=10&&linea.length()>0) {
							if(linea.matches("([a-zA-Z]+[A-Za-z0-9]*)")){
								registros[0] = linea;
								registros[1] = "Simbolo";
								modeloAux.addRow(registros);
							}else {
								registros[0] = linea;
								registros[1] = "Elemento no identificado";
								modeloAux.addRow(registros);
							}
						}else {
								registros[0] = linea;
							    registros[1] = "Elemento no identificado";
							    modeloAux.addRow(registros);
						}
					    break;
				  } //FIN SWITCH
					
				} //FIN IF GENERAL
				
				limiteInf = limiteInf + 1;
				if(contLineas == limiteSup) {
					break;
				}				
		      }		      		    			      
			}// FIN LECTURA DATOS ARCHIVO
			
			arch.close();
			br.close(); 			
		}catch(Exception e){
			JOptionPane.showMessageDialog(null, "Error xd " + e.getMessage());
		}		
		return modeloAux;
	}
	
	public static int hex(String color_hex ){
        return Integer.parseInt(color_hex,  16 );
    }
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		String evento = arg0.getActionCommand();
		switch(evento) {
		    case "anterior":
		    	if(indV == 0 || indT == 1) {
		    		this.setAlwaysOnTop( false );
					JOptionPane.showMessageDialog(null, "Ya estas en los primeros 20 renglones");
					this.setAlwaysOnTop( true);
				} else {
					indV = indV - 1;
					txt.setText(codSep[indV]);
					muestraLineas(indV);
					
					indT = indT - 1;
					modeloAux = IdentificaTodo(indT);				    
				    tabla.setModel(modeloAux);
				}
			    break;
			   
		    case "siguiente":
		    	if(indV == (limSuperior-1)) {
		    		this.setAlwaysOnTop( false );
					JOptionPane.showMessageDialog(null, "Ya estas en el limite superior");
					this.setAlwaysOnTop( true);
		    	} else {
					indV = indV + 1;
					txt.setText(codSep[indV]);
					muestraLineas(indV);
					
					indT = indT + 1;
					modeloAux = IdentificaTodo(indT);				    
				    tabla.setModel(modeloAux);
				}
				break;
								
			case "salir":
			   this.setVisible(false);
			   break;
		}		
	}
	
	public void muestraLineas(int indV) {		
		if(indV == 0) {
			renglones.setText(" Linea: 0 - 20");
		}else{
			renglones.setText(" Linea: "+((indV*20)+1)+" - "+ ((indV*20)+20));
		}
	}
	
}
