import javax.swing.*;
import javax.swing.filechooser.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class AnalizadorArchivosGUI extends JFrame {
    private static final int ELEMENTOS_POR_PAGINA = 10;
    private List<String> elementos = new ArrayList<>();
    private int paginaActual = 1;
    private int totalPaginas = 1;
    
    private JTextArea areaContenido;
    private JTextArea areaElementos;
    private JLabel etiquetaPagina;
    private JButton btnAnterior, btnSiguiente;
    private JLabel etiquetaTotal;
    private JLabel etiquetaRuta;
    
    public AnalizadorArchivosGUI() {
        setTitle("Analizador de Archivos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setResizable(true);
        
        crearInterfaz();
    }
    
    private void crearInterfaz() {
        // Panel superior con botones
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBackground(new Color(0, 0, 0));
        panelSuperior.setPreferredSize(new Dimension(0, 70));
        panelSuperior.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 15));
        
        JButton btnAbrir = new JButton("Abrir Archivo");
        btnAbrir.setFont(new Font("Arial", Font.BOLD, 12));
        btnAbrir.setBackground(new Color(0, 120, 215));
        btnAbrir.setForeground(Color.WHITE);
        btnAbrir.setFocusPainted(false);
        btnAbrir.addActionListener(e -> abrirArchivo());
        panelSuperior.add(btnAbrir);
        
        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setFont(new Font("Arial", Font.BOLD, 12));
        btnLimpiar.setBackground(new Color(200, 50, 50));
        btnLimpiar.setForeground(Color.WHITE);
        btnLimpiar.setFocusPainted(false);
        btnLimpiar.addActionListener(e -> limpiar());
        panelSuperior.add(btnLimpiar);
        
        etiquetaRuta = new JLabel("No hay archivo seleccionado");
        etiquetaRuta.setForeground(Color.WHITE);
        etiquetaRuta.setFont(new Font("Arial", Font.PLAIN, 11));
        panelSuperior.add(etiquetaRuta);
        
        // Panel central dividido (contenido y elementos)
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(450);
        
        // Panel izquierdo: Contenido del archivo
        JPanel panelIzq = new JPanel(new BorderLayout());
        panelIzq.setBorder(BorderFactory.createTitledBorder("Contenido del Archivo"));
        panelIzq.setBackground(Color.black);
        
        areaContenido = new JTextArea();
        areaContenido.setEditable(false);
        areaContenido.setFont(new Font("Courier New", Font.PLAIN, 10));
        areaContenido.setBackground(new Color(0, 0, 255));
        areaContenido.setForeground(new Color(200, 200, 200));
        areaContenido.setLineWrap(true);
        areaContenido.setWrapStyleWord(true);
        
        JScrollPane scrollContenido = new JScrollPane(areaContenido);
        scrollContenido.setBorder(null);
        panelIzq.add(scrollContenido, BorderLayout.CENTER);
        
        // Panel derecho: Lista de elementos
        JPanel panelDer = new JPanel(new BorderLayout());
        panelDer.setBorder(BorderFactory.createTitledBorder("Elementos Encontrados"));
        panelDer.setBackground(Color.black);
        
        areaElementos = new JTextArea();
        areaElementos.setEditable(false);
        areaElementos.setFont(new Font("Courier New", Font.PLAIN, 11));
        areaElementos.setBackground(new Color(0, 0, 255));
        areaElementos.setForeground(new Color(100, 200, 100));
        
        JScrollPane scrollElementos = new JScrollPane(areaElementos);
        scrollElementos.setBorder(null);
        panelDer.add(scrollElementos, BorderLayout.CENTER);
        
        // Panel de paginación
        JPanel panelPaginacion = new JPanel();
        panelPaginacion.setBackground(new Color(0, 0, 255));
        panelPaginacion.setPreferredSize(new Dimension(0, 50));
        panelPaginacion.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));
        
        btnAnterior = new JButton("<- Anterior");
        btnAnterior.setFont(new Font("Arial", Font.BOLD, 11));
        btnAnterior.setBackground(new Color(100, 100, 100));
        btnAnterior.setForeground(Color.WHITE);
        btnAnterior.setFocusPainted(false);
        btnAnterior.setEnabled(false);
        btnAnterior.addActionListener(e -> mostrarPaginaAnterior());
        panelPaginacion.add(btnAnterior);
        
        etiquetaPagina = new JLabel("Página 1 de 1");
        etiquetaPagina.setForeground(Color.WHITE);
        etiquetaPagina.setFont(new Font("Arial", Font.BOLD, 12));
        panelPaginacion.add(etiquetaPagina);
        
        btnSiguiente = new JButton("Siguiente ->");
        btnSiguiente.setFont(new Font("Arial", Font.BOLD, 11));
        btnSiguiente.setBackground(new Color(100, 100, 100));
        btnSiguiente.setForeground(Color.WHITE);
        btnSiguiente.setFocusPainted(false);
        btnSiguiente.setEnabled(false);
        btnSiguiente.addActionListener(e -> mostrarPaginaSiguiente());
        panelPaginacion.add(btnSiguiente);
        
        etiquetaTotal = new JLabel("0 elementos");
        etiquetaTotal.setForeground(Color.WHITE);
        etiquetaTotal.setFont(new Font("Arial", Font.PLAIN, 11));
        panelPaginacion.add(etiquetaTotal);
        
        panelDer.add(panelPaginacion, BorderLayout.SOUTH);
        
        splitPane.setLeftComponent(panelIzq);
        splitPane.setRightComponent(panelDer);
        
        // Agregar componentes al frame
        add(panelSuperior, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);
        
        // Configurar estilo general
        UIManager.put("TitledBorder.titleColor", Color.WHITE);
        setBackground(new Color(45, 45, 48));
    }
    
    private void abrirArchivo() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Selecciona un archivo para analizar");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        
        int resultado = fileChooser.showOpenDialog(this);
        
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = fileChooser.getSelectedFile();
            procesarArchivo(archivoSeleccionado);
        }
    }
    
    private void procesarArchivo(File archivo) {
        try {
            // Validar archivo
            if (!archivo.exists() || !archivo.isFile() || !archivo.canRead()) {
                JOptionPane.showMessageDialog(this, 
                    "El archivo no existe o no es accesible.", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Leer contenido
            String contenido = new String(Files.readAllBytes(archivo.toPath()));
            
            // Mostrar contenido
            areaContenido.setText(contenido);
            etiquetaRuta.setText("" + archivo.getAbsolutePath());
            
            // Separar elementos
            separarElementos(contenido);
            
            // Mostrar primera página
            paginaActual = 1;
            actualizarPaginacion();
            mostrarPaginaActual();
            
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error al leer el archivo: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void separarElementos(String contenido) {
        elementos.clear();
        String[] items = contenido.split("[\\s,;:.!?\\(\\)\\[\\]\\{\\}]+");
        
        for (String item : items) {
            if (!item.isEmpty()) {
                elementos.add(item);
            }
        }
        
        totalPaginas = Math.max(1, (int) Math.ceil((double) elementos.size() / ELEMENTOS_POR_PAGINA));
        etiquetaTotal.setText(elementos.size() + " elementos");
    }
    
    private void mostrarPaginaActual() {
        if (elementos.isEmpty()) {
            areaElementos.setText("No hay elementos para mostrar");
            return;
        }
        
        int inicio = (paginaActual - 1) * ELEMENTOS_POR_PAGINA;
        int fin = Math.min(inicio + ELEMENTOS_POR_PAGINA, elementos.size());
        
        StringBuilder sb = new StringBuilder();
        
        sb.append("  LISTA DE ELEMENTOS (Página ")
          .append(String.format("%d de %d", paginaActual, totalPaginas))
          .append(")\n");
        
        
        for (int i = inicio; i < fin; i++) {
            sb.append(String.format("%4d. %s\n", i + 1, elementos.get(i)));
        }
        
        sb.append("\n").append("─".repeat(40)).append("\n");
        sb.append(String.format("Mostrando %d a %d de %d elementos", 
            inicio + 1, fin, elementos.size()));
        
        areaElementos.setText(sb.toString());
        areaElementos.setCaretPosition(0);
    }
    
    private void actualizarPaginacion() {
        etiquetaPagina.setText("Página " + paginaActual + " de " + totalPaginas);
        btnAnterior.setEnabled(paginaActual > 1);
        btnSiguiente.setEnabled(paginaActual < totalPaginas);
    }
    
    private void mostrarPaginaAnterior() {
        if (paginaActual > 1) {
            paginaActual--;
            actualizarPaginacion();
            mostrarPaginaActual();
        }
    }
    
    private void mostrarPaginaSiguiente() {
        if (paginaActual < totalPaginas) {
            paginaActual++;
            actualizarPaginacion();
            mostrarPaginaActual();
        }
    }
    
    private void limpiar() {
        areaContenido.setText("");
        areaElementos.setText("");
        elementos.clear();
        etiquetaRuta.setText("No hay archivo seleccionado");
        etiquetaPagina.setText("Página 1 de 1");
        etiquetaTotal.setText("0 elementos");
        paginaActual = 1;
        totalPaginas = 1;
        btnAnterior.setEnabled(false);
        btnSiguiente.setEnabled(false);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            AnalizadorArchivosGUI frame = new AnalizadorArchivosGUI();
            frame.setVisible(true);
        });
    }
}