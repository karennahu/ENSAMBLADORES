/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnsmbladorProyecto;

import javax.swing.JFrame;

/**
 *
 * @author LUGO HERNANDEZ
 */
public class VentanaTablaSimbolos extends JFrame{
    
    public VentanaTablaSimbolos() {
		this.setTitle("Tabla de Simbolos");
	}
}
