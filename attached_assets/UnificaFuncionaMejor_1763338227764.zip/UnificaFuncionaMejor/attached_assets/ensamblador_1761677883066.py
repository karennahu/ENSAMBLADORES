import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import re
from collections import defaultdict

class AnalizadorLexico:
    def __init__(self, root):
        self.root = root
        self.root.title("Analizador Lexicográfico")
        self.root.geometry("1000x700")
        
        # Conjuntos de elementos válidos (ampliados con categorías)
        self.categorias = {
            "Instrucciones": {
                "Aritméticas": {"AAM", "AAS", "IDIV", "MUL"},
                "Control": {"IRET", "INT", "JNA", "JNC", "JNL", "JO", "LOOP", "JBE"},
                "Lógicas": {"NOT", "SHL", "RCL"},
                "Transferencia": {"LAHF", "MOV", "XCHG"},
                "Flags": {"STD", "STI"}
            },
            "Pseudoinstrucciones": {
                "Directivas": {".CODE", ".DATA", ".STACK", "SEGMENT", "ENDS"},
                "Declaración": {"DB", "DW", "DD"},
                "Procedimientos": {"PROC", "ENDP"},
                "Control": {"END"}
            },
            "Registros": {
                "Generales": {"AX", "BX", "CX", "DX"},
                "Índice": {"SI", "DI", "BP", "SP"},
                "Segmento": {"CS", "DS", "ES", "SS"},
                "8-bit": {"AH", "AL", "BH", "BL", "CH", "CL", "DH", "DL"},
                "Especiales": {"IP", "FLAGS"}
            },
            "Elementos Compuestos": {
                "Segmentos": {".CODE SEGMENT", ".DATA SEGMENT", ".STACK SEGMENT"},
                "Punteros": {"BYTE PTR", "WORD PTR"},
                "Arrays": {"DUP("}
            }
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        # Frame principal
        main_frame = tk.Frame(self.root, padx=10, pady=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Panel de selección de archivo
        file_frame = tk.Frame(main_frame)
        file_frame.pack(fill=tk.X, pady=5)
        
        tk.Label(file_frame, text="Archivo:").pack(side=tk.LEFT)
        
        self.file_entry = tk.Entry(file_frame, width=70)
        self.file_entry.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=5)
        
        browse_btn = tk.Button(file_frame, text="Buscar", command=self.buscar_archivo)
        browse_btn.pack(side=tk.LEFT)
        
        analyze_btn = tk.Button(main_frame, text="Analizar", command=self.analizar_archivo)
        analyze_btn.pack(pady=5)
        
        # Panel de pestañas
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Pestaña de contenido
        self.content_tab = tk.Frame(self.notebook)
        self.content_text = scrolledtext.ScrolledText(self.content_tab, wrap=tk.WORD, font=('Courier', 10))
        self.content_text.pack(fill=tk.BOTH, expand=True)
        self.notebook.add(self.content_tab, text="Contenido")
        
        # Pestaña de resultados
        self.results_tab = tk.Frame(self.notebook)
        
        # Treeview con más columnas
        self.results_tree = ttk.Treeview(
            self.results_tab, 
            columns=("Categoría", "Tipo", "Clasificación"), 
            show="headings"
        )
        
        # Configurar columnas
        self.results_tree.heading("#0", text="Elemento")
        self.results_tree.heading("Categoría", text="Categoría")
        self.results_tree.heading("Tipo", text="Tipo")
        self.results_tree.heading("Clasificación", text="Clasificación General")
        
        self.results_tree.column("#0", width=250, anchor='w')
        self.results_tree.column("Categoría", width=150, anchor='w')
        self.results_tree.column("Tipo", width=150, anchor='w')
        self.results_tree.column("Clasificación", width=200, anchor='w')
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(self.results_tab, orient="vertical", command=self.results_tree.yview)
        self.results_tree.configure(yscrollcommand=scrollbar.set)
        
        self.results_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.notebook.add(self.results_tab, text="Resultados")
        
        # Estadísticas
        self.stats_frame = tk.Frame(main_frame)
        self.stats_frame.pack(fill=tk.X, pady=5)
        
        self.stats_label = tk.Label(self.stats_frame, text="Estadísticas: ")
        self.stats_label.pack(side=tk.LEFT)
        
    def buscar_archivo(self):
        filepath = filedialog.askopenfilename()
        if filepath:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, filepath)
            self.mostrar_contenido(filepath)
    
    def mostrar_contenido(self, filepath):
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
                self.content_text.delete(1.0, tk.END)
                self.content_text.insert(tk.END, content)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo leer el archivo:\n{str(e)}")
    
    def analizar_archivo(self):
        filepath = self.file_entry.get()
        if not filepath:
            messagebox.showwarning("Advertencia", "Seleccione un archivo primero")
            return
            
        try:
            with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                contenido = f.read()
            
            # Procesar contenido
            contenido = self.eliminar_comentarios(contenido)
            elementos = self.extraer_elementos(contenido)
            resultados = self.identificar_elementos(elementos)
            
            # Mostrar resultados
            self.mostrar_resultados(resultados)
            self.mostrar_estadisticas(resultados)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error al analizar el archivo:\n{str(e)}")
    
    def eliminar_comentarios(self, contenido):
        return re.sub(r';.*$', '', contenido, flags=re.MULTILINE)
    
    def extraer_elementos(self, contenido):
        # Manejar elementos compuestos primero
        for categoria, items in self.categorias["Elementos Compuestos"].items():
            for compuesto in items:
                contenido = contenido.replace(compuesto, compuesto.replace(" ", "___"))
        
        # Extraer cadenas entre comillas
        contenido = re.sub(r'(["\'])(?:(?=(\\?))\2.)*?\1', self.reemplazar_espacios, contenido)
        
        # Extraer expresiones entre corchetes
        contenido = re.sub(r'\[.*?\]', self.reemplazar_espacios, contenido)
        
        # Extraer DUP(...)
        contenido = re.sub(r'DUP\(.*?\)', self.reemplazar_espacios, contenido)
        
        # Tokenizar
        tokens = re.findall(r'[^\s,\t\n:]+|".*?"|\'.*?\'|\[.*?\]|DUP\(.*?\)', contenido)
        
        # Restaurar elementos compuestos
        tokens = [token.replace("___", " ") for token in tokens]
        
        return tokens
    
    def reemplazar_espacios(self, match):
        return match.group(0).replace(" ", "§")
    
    def identificar_elementos(self, elementos):
        resultados = []
        
        for elemento in elementos:
            # Buscar en todas las categorías
            categoria_encontrada = None
            tipo_encontrado = None
            clasificacion = None
            
            elemento_upper = elemento.upper()
            
            # Buscar en categorías específicas
            for categoria_principal, subcategorias in self.categorias.items():
                for subcategoria, items in subcategorias.items():
                    if elemento_upper in items:
                        categoria_encontrada = categoria_principal
                        tipo_encontrado = subcategoria
                        clasificacion = categoria_principal
                        break
                if categoria_encontrada:
                    break
            
            # Si no se encontró en categorías específicas, verificar otros casos
            if not categoria_encontrada:
                if (elemento.startswith('"') and elemento.endswith('"')) or (elemento.startswith("'") and elemento.endswith("'")):
                    clasificacion = "Constante caracter"
                elif elemento.startswith("[") and elemento.endswith("]"):
                    clasificacion = "Dirección de memoria"
                elif "DUP(" in elemento_upper:
                    clasificacion = "Expresión DUP"
                elif self.es_constante_numerica(elemento):
                    clasificacion = self.tipo_constante(elemento)
                elif self.es_simbolo_valido(elemento):
                    clasificacion = "Símbolo"
                else:
                    clasificacion = "Elemento inválido"
            
            resultados.append((elemento, categoria_encontrada or "Otros", tipo_encontrado or "-", clasificacion))
        
        return resultados
    
    def es_constante_numerica(self, elemento):
        return (re.fullmatch(r'\d+', elemento) or
                re.fullmatch(r'(0x[0-9A-F]+)|([0-9A-F]+H)', elemento, re.IGNORECASE) or
                re.fullmatch(r'[01]+B', elemento, re.IGNORECASE))
    
    def tipo_constante(self, elemento):
        if re.fullmatch(r'(0x[0-9A-F]+)|([0-9A-F]+H)', elemento, re.IGNORECASE):
            return "Constante hexadecimal"
        elif re.fullmatch(r'[01]+B', elemento, re.IGNORECASE):
            return "Constante binaria"
        else:
            return "Constante decimal"
    
    def es_simbolo_valido(self, elemento):
        return re.fullmatch(r'[a-zA-Z_][a-zA-Z0-9_]*', elemento)
    
    def mostrar_resultados(self, resultados):
        self.results_tree.delete(*self.results_tree.get_children())
        
        for elemento, categoria, tipo, clasificacion in resultados:
            self.results_tree.insert(
                "", 
                tk.END, 
                text=elemento, 
                values=(categoria, tipo, clasificacion)
            )
    
    def mostrar_estadisticas(self, resultados):
        estadisticas = defaultdict(int)
        for _, categoria, _, clasificacion in resultados:
            if categoria != "Otros":
                estadisticas[categoria] += 1
            estadisticas[clasificacion] += 1
        
        stats_text = "Estadísticas: "
        stats_text += " | ".join([f"{k}: {v}" for k, v in estadisticas.items()])
        self.stats_label.config(text=stats_text)

if __name__ == "__main__":
    root = tk.Tk()
    app = AnalizadorLexico(root)
    root.mainloop()