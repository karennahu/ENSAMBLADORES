package EnsmbladorProyecto;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Archivo {
	public static boolean validarArchivo(String nombre) {
		boolean bandera = false;
		Pattern pat = Pattern.compile("\\w*\\.asm");
		Matcher mat = pat.matcher(nombre);
		if (mat.matches()) {
	         bandera = true;
	     } else {
	         bandera = false;                                                                                
	    }
		return bandera;
	}
}
