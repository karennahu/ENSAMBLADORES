/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EnsmbladorProyecto;

/**
 *
 * @author LUGO HERNANDEZ
 */
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class VentanaSegmentoDyP extends JFrame implements ActionListener {
    //JTextArea txt;
	//int cont=0;
	//JTable tabla;
	DefaultTableModel modelo;
	//private JTextField renglones;
	//int limSuperior=0;
    //int indV, indT;
	String[] codSep = new String[100];   
    DefaultTableModel modeloAux = new DefaultTableModel(null, new Object[] {"Token", "Valor"});
    JTable tabla;
    int limSuperior=0;
    int indV, indT;
	private JTextField renglones;
	private JLabel totLineas;
	JTextArea txt;
    public String rutanueva="C:\\Users\\Public\\archivo1.txt";  // ARCHIVO CON CODIGO LIMPIO
    String ArchSeparado="C:\\Users\\Public\\archivo2.txt";		
    
	public VentanaSegmentoDyP(String[] lineas, int cont) {
		//this.setTitle("Ventana segmento de datos y pila");
		//this.setResizable(false); //PARA QUE NO SE PUEDA CAMBIAR EL TAMAÑO DE LA VENTANA
		//this.setContentPane(getPanel());
	    //this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		ArrayList<String> codigo = new ArrayList<String>();          
	    String CodigoComp="";  // VARIABLE PARA METER EL CODIGO COMPLETO         			
	    this.setTitle("Ventana separa e identifica elementos");   // TITULO DE LA VENTANA
		this.setResizable(false);  //PARA QUE NO SE PUEDA CAMBIAR EL TAMAÑO DE LA VENTANA EN EJECUCION		  
     	this.setContentPane(getPanel());  // AGREGAS EL PANEL A LA VENTANA						  
     	for(String cad: lineas) {  // METE EN UN SOLO STRING EL CODIGO DEL VECTOR
	    	if(cad != null) {
	    		CodigoComp =  CodigoComp + cad;	
	    		//System.out.println(CodigoComp);
	    	}
	    }	     	
 //************************************************************************************* 
        divideV(ArchSeparado); // PARA DIVIDiR EN EL VECTOR GLOBAL CODSEP PAQUETES DE 20 INEAS   
  // ***********************   CALCLULA LIMITE SUPERIOR DEL VECTOR ********************************************* 
        for(int i =0; i<100;i++) {
        	if(codSep[i]!= null) {
        		codigo.add(codSep[i]);
        	}
        }
        limSuperior = codigo.size(); 
        System.out.println(limSuperior);
// ***********************************************************************************************************                
		renglones.setText(" Linea: 0 - 40");
	    totLineas.setText("Total de lineas: " + cont);
	    indV=0;
        txt.setText(codSep[indV]);		                
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	    
	}
	
	public void divideV(String ruta) {
 	   String cad = "";	  
 	   int contL = 0;
 	   int indV= 0;
		   try {
			   FileReader arch = new FileReader(ruta);
			   BufferedReader br = new BufferedReader(arch);
			   String linea="";			   
			   while((linea = br.readLine()) != null) { 				   
			   		contL =  contL + 1;
			   		//if(contL == 1) {
			   		// cad = linea;	
			   		//}else {
			   		 cad = cad +"\n"+ linea;
			   		//}
			   		if(contL%40 == 0) {
			   			codSep[indV] = cad;
			   			//System.out.println(codSep[indV]);
			   			cad = "";
			   			indV = indV+1;
			   		} 					 	  				  		   
			   }
	   		  codSep[indV] = cad;
	   		//  System.out.println(codSep[indV]);
			  arch.close();
			  br.close();		   
		   }catch(Exception e){
			   	 JOptionPane.showMessageDialog(null, "Error");
		   }	
 	}
	public JPanel getPanel() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
        JLabel etq = new JLabel("Identificacion de lineas de los segmentos de datos y pila");
        etq.setBounds(40,5,460,30);
        etq.setFont(new Font("arial", 3,16));
        panel.add(etq);            
        JButton btnAnterior = new JButton();
		btnAnterior.setBounds(220,490,40,35);
		ImageIcon imgAnt = new ImageIcon("src/ant.png");
		btnAnterior.setIcon(new ImageIcon(imgAnt.getImage().getScaledInstance(btnAnterior.getWidth(),
				btnAnterior.getHeight(),Image.SCALE_SMOOTH)));
		btnAnterior.addActionListener(this);
		btnAnterior.setActionCommand("anterior");
		panel.add(btnAnterior);		
		JButton btnSiguiente = new JButton();
		btnSiguiente.setBounds(310,490,40,35);
		ImageIcon imgSig = new ImageIcon("src/sig.png");
		btnSiguiente.setIcon(new ImageIcon(imgSig.getImage().getScaledInstance(btnSiguiente.getWidth(),
				btnSiguiente.getHeight(),Image.SCALE_SMOOTH)));
		btnSiguiente.addActionListener(this);
		btnSiguiente.setActionCommand("siguiente");
		panel.add(btnSiguiente);	
		renglones = new JTextField();
		renglones.setBounds(15,490,200,35);
		renglones.setEditable(false);
        panel.add(renglones);
		// **************************  TABLA ***********************************
	    modelo = new DefaultTableModel();
		modelo.addColumn("Linea");
		modelo.addColumn("Identificacion");		
		modelo.addColumn("Descricion");		
	
		//String[] p1={"datasegment", "incorrecto", "Falta espacio"};
		//modelo.addRow(p1);
		IdentificaTodo("C:\\Users\\Public\\archivo1.txt");
		 indT=1;
		 
		

		tabla = new JTable(modelo);		
		tabla.setBounds(5,60,630,420);		
		JScrollPane scroll = new JScrollPane(tabla);
		scroll.setBounds(5, 60, 700, 420);
	    scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	    scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);		
	    panel.add(scroll);	    
		
	    return panel;
	}	
	
	public void IdentificaTodo(String ruta) {
		   String cad = "";
		   int contEnds=0;
		     boolean band1,band2,band3,band4,band5,band6,band7,band8,band9,band77,band99;
		     boolean band10,band11,band12,band13,band14,band15,band16,band17,band18,band19,band144,band155,band166,band177,band188,band199;
		  ArrayList<String> lista = new ArrayList<String>();
          String estado = null;
		   try {
			   FileReader arch = new FileReader(ruta);
			   BufferedReader br = new BufferedReader(arch);
			   String linea="";	
			   
			   String[] lineaArch = new String[3];
			   int valor2 = 0;
			   
			   while((linea = br.readLine()) != null) { 
				   
				   if(linea.toUpperCase().equals("ENDS")) {
					   contEnds = contEnds+1;					   
				   }
				   
				   if(linea.toUpperCase().equals("DATA SEGMENT")) {
					   valor2 =1;
				   }else if(linea.toUpperCase().equals("STACK SEGMENT")) {
					   valor2 =1;
				   }else if(linea.toUpperCase().equals("CODE SEGMENT")) {
					   valor2 =1;
				   }else if(linea.toUpperCase().equals("BYTE PTR")) {
					   valor2 =1;
				   }else if(linea.toUpperCase().equals("WORD PTR")) {
					   valor2 =1;
				   }else if(linea.toUpperCase().equals("ENDS")) {
					   valor2 =1;					   
				   }else {
					   	//Pseudoinstruccion
					    band1 = linea.matches("^[a-zA-Z]{1}[a-zA-Z0-9]{0,9}[ ]+[d]{1}[b]{1}[ ]+(([\']{1}.+[\']{1})|([\"]{1}.+[\"]{1}))$"); 
					    band2 = linea.matches("^[a-zA-Z]{1}[a-zA-Z0-9]{0,9}[ ]+[d]{1}[b]{1}[ ]+(([\']{1}.+)|([\"]{1}.+))$");
				        //Hexadecimal
				        band3 = linea.matches("^[a-zA-Z]{1}[a-zA-Z0-9]{0,9}[ ]+[d]{1}[b]{1}[ ]+[0]{1}[0-9 ]+[H]{1}$");
				        //Decimal
				        band4 = linea.matches("^[a-zA-Z]{1}[a-zA-Z0-9]{0,9}[ ]+([d]{1}[b]{1}|[d]{1}[w]{1})[ ]+[0-9 ]+$");
				        //DUP
				        band5 = linea.matches("^[d]{1}[w]{1}[ ]+[0-9 ]+[ ]+[d]{1}[u]{1}[p]{1}([(]{1}[0-9]+[)]{1})$");
				        //int o llamada al 2
				        band6 = linea.matches("^[i]{1}[n]{1}[t]{1}[ ][2]{1}[1]{1}[h]{1}$");
				        //mov
				        band7 = linea.matches("^[m]{1}[o]{1}[v]{1}[ ]([a]{1}[h]{1}|[d]{1}[l]{1})[ ](([0-9]+[ ]+|[0-9]+)|([a-zA-Z]+[ ]+|[a-zA-Z]+))$");
				        band77 = linea.matches("^[m]{1}[o]{1}[v]{1}[ ]([a]{1}[h]{1}|[d]{1}[l]{1})[ ](([a-zA-Z]{1}[0-9]+[ ]+|[a-zA-Z]{1}[0-9]+)|([0-9]{1}[a-zA-Z]+[ ]+|[0-9]{1}[a-zA-Z]+))$");//error de variable
				        //ret
				        band8 = linea.matches("^[r]{1}[e]{1}[t]{1}$");
				        //sub
				        band9 = linea.matches("^[s]{1}[u]{1}[b]{1}[ ]+[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+([0-9]{1}[0-9]+|[0-9]{1}[0-9]+[ ]+)$");
				        
				        band99 = linea.matches("^[s]{1}[u]{1}[b]{1}[ ]+[0-9]{1}[a-zA-Z0-9]+[ ]+([a-zA-Z]{1}[0-9]+|[0-9]{1}[a-zA-Z]+[ ]+)$");//error de variable
				        //cbw
				        band10 = linea.matches("^[c]{1}[b]{1}[w]{1}$");				        
				        //cwd
				        band11 = linea.matches("^[c]{1}[w]{1}[d]{1}$");
				        //pusha
				        band12 = linea.matches("^[p]{1}[u]{1}[s]{1}[h]{1}[a]{1}$");
				        //stosw
				        band13 = linea.matches("^[s]{1}[t]{1}[o]{1}[s]{1}[w]{1}$");
				        //lds
				        band14 = linea.matches("^[l]{1}[d]{1}[s]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)$");
				        band144 = linea.matches("^[l]{1}[d]{1}[s]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+)$");//error de variable
				        
				        //push
				        band15 = linea.matches("^([p]{1}[u]{1}[s]{1}[h]{1}|([p]{1}[u]{1}[s]{1}[h]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)))$");
				        band155 = linea.matches("^([p]{1}[u]{1}[s]{1}[h]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+))$");//error de variable
				        
				        //ja
				        band16 = linea.matches("^[j]{1}[a]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)$");
				        band166 = linea.matches("^[j]{1}[a]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+)$");//error de variable
				        //jnc
				        band17 = linea.matches("^[j]{1}[n]{1}[c]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)$");
				        band177 = linea.matches("^[j]{1}[n]{1}[c]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+)$");//error de variable
				        
				        //jnl
				        band18 = linea.matches("^[j]{1}[n]{1}[l]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)$");				        
				        band188 = linea.matches("^[j]{1}[n]{1}[l]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+)$");//error de variable
				        
				        //jnp
				        band19 = linea.matches("^[j]{1}[n]{1}[p]{1}[ ]+([a-zA-Z]{1}[a-zA-Z0-9]+|[a-zA-Z]{1}[a-zA-Z0-9]+[ ]+)$");				        
				        band199 = linea.matches("^[j]{1}[n]{1}[p]{1}[ ]+([0-9]{1}[a-zA-Z0-9]+|[0-9]{1}[a-zA-Z0-9]+[ ]+)$");//error de variable
				        
					    if(band1  == true) {
				        		valor2 = 11;
				        }else if (band2 == true){
			        		    valor2 = 22;
						}else if (band3 == true){//hexadecimal
		        		    valor2 = 33;					   					  
						}else if (band4 == true){//decimal
		        		    valor2 = 44;					   					  
						}else if (band5 == true){//Dup
		        		    valor2 = 55;					   					  
						}else if (band6 == true){//Llamado al 2
		        		    valor2 = 60;					   					  
						}else if (band7 == true){//mov
		        		    valor2 = 70;					   					  
						}else if (band8 == true){//ret
		        		    valor2 = 80;					   					  
						}else if (band9 == true){//ret
		        		    valor2 = 90;					   					  
						}else if (band10 == true){//cbw
		        		    valor2 = 110;					   					  
						}else if (band11 == true){//cwd
		        		    valor2 = 111;					   					  
						}else if (band12 == true){//pusha
		        		    valor2 = 112;					   					  
						}else if (band13 == true){//stows
		        		    valor2 = 113;					   					  
						}else if (band14 == true){//lds
		        		    valor2 = 114;					   					  
						}else if (band15 == true){//push
		        		    valor2 = 115;					   					  
						}else if (band16 == true){//ja
		        		    valor2 = 116;					   					  
						}else if (band17 == true){//jnc
		        		    valor2 = 117;					   					  
						}else if (band18 == true){//jnl
		        		    valor2 = 118;					   					  
						}else if (band19 == true){//jnp
		        		    valor2 = 119;					   					  
						}else if (band77 == true||band99 == true||band144 == true||band155 == true||band166 == true||band177 == true||band188 == true||band199 == true){//jnp
		        		    valor2 = 202;					   					  
						}
					    
				   }
				   				   
				   switch(valor2) {
				   		case 1:
				   		   lineaArch[0] = linea;
						   lineaArch[1] = "Correcto";
						   lineaArch[2] = "Pseudoinstruccion";
						   modelo.addRow(lineaArch);
						   valor2 = 0;
						   break;					   
						  
				   		case 11:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Constante Caracter";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		case 22:										
					   	   lineaArch[0]=linea;
						   lineaArch[1]="Incorrecto";
						   lineaArch[2]="Error en las comillas";
						   modelo.addRow(lineaArch);
						   valor2 = 0;
				   		case 33:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Constante numerica Hexadecimal";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		case 44:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Constante numerica Decimal";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		case 55:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Instruccion Dup";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;	   	     
				   		
				   		case 60:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="correcto";
							   lineaArch[2]="Llamada al dos";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		
				   		case 70:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Instruccion mod";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		case 80:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Instruccion ret";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		case 90:										
						   	   lineaArch[0]=linea;
							   lineaArch[1]="Correcto";
							   lineaArch[2]="Instruccion Sub";
							   modelo.addRow(lineaArch);
							   valor2 = 0;
							   break;
				   		
				   		case 110:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion CBW";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 111:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion CWD";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 112:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion PUSHA";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 113:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion STOSW";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 114:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion LDS";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 115:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion PUSH";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 116:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion JA";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 117:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion JNC";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 118:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion JNL";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 119:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Correcto";
				   			lineaArch[2]="Instruccion JNP";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;
				   		case 202:										
				   			lineaArch[0]=linea;
				   			lineaArch[1]="Incorrecto";
				   			lineaArch[2]="Error de constante";
				   			modelo.addRow(lineaArch);
				   			valor2 = 0;
				   			break;	   	     
						   
				   		default:
				   		   lineaArch[0]=linea;
						   lineaArch[1]="Incorrecto";
						   lineaArch[2]= linea + " elemento no identificado";
					       modelo.addRow(lineaArch);
					       valor2 = 0;
				   	       break;				   	       				   		 						  				   
				   }				  				   				   
				System.out.println(linea);
				 if(contEnds == 2) {
					  break;
				   }		   
			   }				   
			   arch.close();
			   br.close();			   
		   }catch(Exception e){
			   	 JOptionPane.showMessageDialog(null, "ErrorPas" + e.getMessage());
		   }	   
	   	}
	
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		String evento = arg0.getActionCommand();
		switch(evento) {
		 case "anterior":
		    	if(indV == 0 || indT == 1) {
		    		this.setAlwaysOnTop( false );
					JOptionPane.showMessageDialog(null, "Ya estas en los primeros 40 renglones");
					this.setAlwaysOnTop( true);
				} else {
					indV = indV - 1;
					txt.setText(codSep[indV]);
					muestraLineas(indV);
					
					indT = indT - 1;
					//modeloAux = IdentificaTodo(indT);				    
				    tabla.setModel(modeloAux);
				}
			    break;
			   
		    case "siguiente":
		    	if(indV == (limSuperior-1)) {
		    		this.setAlwaysOnTop( false );
					JOptionPane.showMessageDialog(null, "Ya estas en el limite superior");
					this.setAlwaysOnTop( true);
		    	} else {
					indV = indV + 1;
					txt.setText(codSep[indV]);
					muestraLineas(indV);
					
					indT = indT + 1;
					//modeloAux = IdentificaTodo(indT);				    
				    tabla.setModel(modeloAux);
				}
				break;
								
			case "salir":
			   this.setVisible(false);
			   break;
		}			
	}
	public void muestraLineas(int indV) {		
		if(indV == 0) {
			renglones.setText(" Linea: 0 - 40");
		}else{
			renglones.setText(" Linea: "+((indV*40)+1)+" - "+ ((indV*40)+40));
		}
	}

}
