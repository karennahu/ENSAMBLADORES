package EnsmbladorProyecto;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Formatter;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Ventana extends JFrame implements ActionListener{
	VentanaSepararElem vSepararElem;
	VentanaSegmentoDyP vIdentificarElem;
	
    int indV, limSuperior;
    boolean archCargado = false;
    String[] lineas = new String[100]; //VECTOR QUE TIENE EL CODIGO EN SECCIONES DE 20 LINEAS
	private static final long serialVersionUID = 1L;
    JTextArea txt;
	private JTextField renglones;
	private JLabel totLineas;
	private JTextField ubicacion;
	DimensionesPantalla d = new DimensionesPantalla();
	int totLineasSep;


	
	public Ventana() {
		agregarMenu();
		d.obtenerTamanio();
		this.setSize(d.getAncho(), d.getAlto());
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setContentPane(getPanel());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

	}

	public void agregarMenu(){
		JMenuBar barra = new JMenuBar();	
		JMenu menu =new JMenu("Menu");		
		JMenuItem abrir = new JMenuItem("Abrir Archivo");
		abrir.addActionListener(this);
		abrir.setActionCommand("abrir");
		JMenuItem salir = new JMenuItem("Salir");
		salir.addActionListener(this);
		salir.setActionCommand("salir");
		barra.add(menu);
		menu.add(abrir);
		menu.add(salir);
		setJMenuBar(barra);
	}
	
	public JPanel getPanel() {
		JPanel panel = new JPanel();
	
		panel.setLayout(null);
		// NEW CODE *******************************
		
        JLabel etq = new JLabel("Proyecto Ensamblador");
        etq.setBounds(110,20,200,60);
        etq.setFont(new Font("arial", 3,18));
        panel.add(etq);
        
        JButton btn2 = new JButton("Separa e identifica elementos");
		btn2.setBounds(80,80,250,30);
        btn2.setFont(new Font("arial", 2,16));
		btn2.addActionListener(this);
        btn2.setActionCommand("separar");
		panel.add(btn2);
		
		JButton btn3 = new JButton("Segmentos de datos y pila");
		btn3.setBounds(80,120,250,30);
        btn3.setFont(new Font("arial", 2,16));  
		btn3.addActionListener(this);
        btn3.setActionCommand("identificaLineas");
		panel.add(btn3);		
		

				
		JButton btnIcon = new JButton();
		btnIcon.setBounds(30,610,40,35);
		btnIcon.addActionListener(this);
            btnIcon.setActionCommand("abrir");
		panel.add(btnIcon);
		
		JButton btnAnterior = new JButton();
		btnAnterior.setBounds(800,610,40,35);
		ImageIcon imgAnt = new ImageIcon("src/ant.png");
		btnAnterior.setIcon(new ImageIcon(imgAnt.getImage().getScaledInstance(btnAnterior.getWidth(),
				btnAnterior.getHeight(),Image.SCALE_SMOOTH)));
		btnAnterior.addActionListener(this);
		btnAnterior.setActionCommand("anterior");
		panel.add(btnAnterior);
		
		JButton btnSiguiente = new JButton();
		btnSiguiente.setBounds(900,610,40,35);
		ImageIcon imgSig = new ImageIcon("src/sig.png");
		btnSiguiente.setIcon(new ImageIcon(imgSig.getImage().getScaledInstance(btnSiguiente.getWidth(),
				btnSiguiente.getHeight(),Image.SCALE_SMOOTH)));
		btnSiguiente.addActionListener(this);
		btnSiguiente.setActionCommand("siguiente");
		panel.add(btnSiguiente);
		
		
		
		//****************************************
		ubicacion = new JTextField();
		ubicacion.setBounds(80,610,330,35);
		ubicacion.setEditable(false);
		
		renglones = new JTextField();
		renglones.setBounds(450,610,150,35);
		renglones.setEditable(false);
		
		totLineas = new JLabel("-------------------------");
	    totLineas.setBounds(1050,600,200,60);
	    totLineas.setFont(new Font("arial", 3,15));
	    panel.add(totLineas);
			
		txt = new JTextArea();
		txt.setBounds(450,20,d.getAncho()-500, d.getAlto()-189);
		txt.setEditable(false);
		
		JScrollPane scroll = new JScrollPane(txt);
        scroll.setBounds(450, 20, d.getAncho()-500, d.getAlto()-189);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
        panel.add(scroll);
        panel.add(ubicacion);
        panel.add(renglones);

        return panel;
	}
	
	public void abrirArchivo() throws FileNotFoundException {
		
		
		int totRenglones=0; //LINEAS DEL ARCHIVO
	    indV=0; //INDICE DEL VECTOR QUE SEPARA LINEAS
		int Vinicio,Vfinal,aux;
		JFileChooser explorador = new JFileChooser();
		explorador.setFileSelectionMode(JFileChooser.FILES_ONLY);
		
		FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos fte", "fte");
		explorador.setFileFilter(filtro);
		
		int seleccion = explorador.showOpenDialog(this);
		
		if(seleccion == JFileChooser.APPROVE_OPTION){
			File archivo = explorador.getSelectedFile();
			String nombre = archivo.getName();
			if(Archivo.validarArchivo(nombre)) {
				try{
					BufferedReader br = new BufferedReader(new FileReader(archivo));//TIENE TODO EL ARCHIVO
					String texto = "";
					String cadena = br.readLine();//LEE LA PRIMERA LINEA
					
					while(cadena!=null){
							if(cadena.contentEquals("")==false) {
								texto = texto + cadena + "\n";
								totRenglones = totRenglones +1;
							}
							if((totRenglones%20)==0) {
								lineas[indV]=texto;
								texto="";
							//	System.out.println(lineas[indV]);
								indV = indV+1;	
							//	System.out.println(totRenglones+"\n");
							}
							cadena = br.readLine();
			        }
					br.close();
					totLineas.setText("Total de renglones: " + totRenglones);
   //********************* CALCULANDO EL INTERVALO DE RENGLONES FALTANTES *********************************									
					aux = (int)(totRenglones/20);// CONJUNTOS DE 20 QUE SI SE GUARDARON		
					System.out.println(totRenglones);
					Vinicio = aux*20; // VALOR INICIO
					Vfinal = (totRenglones % 20) + (aux*20); // VALOR FINAL
					if((totRenglones % 20) == 0) {
						limSuperior = aux-1;
					}else {
						limSuperior = aux;
					}								
	//********************* GUARDA LO RENGLONES FALTANTES**************************************************
					totRenglones = 0;
					BufferedReader br2 = new BufferedReader(new FileReader(archivo));//TIENE TODO EL ARCHIVO
					String texto2 = "";
					String cadena2 = br2.readLine();//LEE LA PRIMERA LINEA				
					while(cadena2!=null){			
						if(cadena2.contentEquals("")==false) {
							if(totRenglones >= Vinicio && totRenglones <= Vfinal) {
								texto2 = texto2 + cadena2 + "\n";
							}
							totRenglones = totRenglones +1;							
						}				
						cadena2 = br2.readLine();
					}
					lineas[indV]=texto2;
					br2.close();
	//*********************************************+++*++***************************************************
								
					ubicacion.setText(archivo.getAbsolutePath());					
					txt.setText(lineas[0]);
					renglones.setText("Linea: 0 - 20");
					indV = 0;
			        //txt.setText(ProcesarTexto.proceso(texto));
			    }catch(IOException e1){
			           JOptionPane.showMessageDialog(null, "Error al leer el archivo");
			    }
			}else {
				JOptionPane.showMessageDialog(null, "�EL ARCHIVO SELECCIONADO ES INVALIDO!");
			}
		}else {
			JOptionPane.showMessageDialog(null, "�NINGUN ARCHIVO SELECCIONADO!");
		}	
	}
		
	  
	
	
	public void Arch() {
		PreparaTodo cargaTodo = new PreparaTodo(lineas);
		totLineasSep = cargaTodo.totLineasSeparadas();
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String evento = arg0.getActionCommand(); 
		
		switch(evento) {
			case "abrir":
					vaciaVector();
					try {
						abrirArchivo();
						Arch();
						archCargado = true;	
					} catch (FileNotFoundException e) {
						JOptionPane.showMessageDialog(null, "ERROR AL ABRIR EL ARCHIVO");
						e.printStackTrace();
					} 		
			     break;
			case "separar":
				if(archCargado == true) {
					vSepararElem= new VentanaSepararElem(lineas, totLineasSep);
					vSepararElem.setSize(780, 580);
					vSepararElem.setLocationRelativeTo(null);
					vSepararElem.setVisible(true);
					vSepararElem.setAlwaysOnTop( true );								
				}else {
			        JOptionPane.showMessageDialog(null, "Tienes que cargar el archivo");
				}
				break;
			case "identificaLineas":
				if(archCargado == true) {
					//vIdentificarElem = new VentanaSegmentoDyP();
					vIdentificarElem.setSize(710, 580);
					vIdentificarElem.setLocationRelativeTo(null);
					vIdentificarElem.setVisible(true);
					vIdentificarElem.setAlwaysOnTop( true );
				}else {
			        JOptionPane.showMessageDialog(null, "Tienes que cargar el archivo");
				}
				break;
				
			
				
			case "anterior":				
				if(indV == 0) {
					JOptionPane.showMessageDialog(null, "Ya estas en los primeros 20 renglones");
				} else {
					indV = indV - 1;
					txt.setText(lineas[indV]);
					muestraLineas(indV);
				}
				break;
				
			case "siguiente":
				if(indV == limSuperior) {
					JOptionPane.showMessageDialog(null, "Ya estas en el limite superior");
				} else {
					indV = indV + 1;
					txt.setText(lineas[indV]);
					muestraLineas(indV);
				}
				break;
		    
				
			case "limpiar":	
			   /*for(int l=0;l<100;l++){
					lineas[l]=null;
				}*/
				borraArch("C:\\Users\\Public\\archivo1.txt");
				borraArch("C:\\Users\\Public\\archivo2.txt");
			    txt.setText("");
			    ubicacion.setText("");
			    renglones.setText("");
			    totLineas.setText("-------------------------");
			    archCargado = false;
			    break;
			
			case "salir":
				System.exit(0);
			break;
		}
		
	}
	
	public void vaciaVector() {
		for(int l=0;l<100;l++){
			lineas[l]=null;
		}
	}
	
	public void borraArch(String direccion) {	
		try {
		File archivo = new File(direccion);
		BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
		bw.write("");
		bw.close();
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, "no borro contenido");
		}
	}
	
	public void muestraLineas(int indV) {		
		if(indV == 0) {
			renglones.setText("Linea: 0 - 40");
		}else{
			renglones.setText("Linea: "+((indV*40)+1)+" - "+ ((indV*40)+40));
		}
	}
}
