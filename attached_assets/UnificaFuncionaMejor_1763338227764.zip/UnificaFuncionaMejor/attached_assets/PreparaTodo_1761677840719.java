package EnsmbladorProyecto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Formatter;

import javax.swing.JOptionPane;

public class PreparaTodo {
	public String rutanueva="C:\\Users\\Public\\archivo1.txt";  // ARCHIVO CON CODIGO LIMPIO
	String ArchSeparado="C:\\Users\\Public\\archivo2.txt";		
    int cont=0;	  
	
	
	public PreparaTodo(String[] lineas){
		 String CodigoComp="";  // VARIABLE PARA METER EL CODIGO COMPLETO         			
		    String codeSeparado= "";

		    boolean bandera;	    	

			for(String cad: lineas) {  // METE EN UN SOLO STRING EL CODIGO DEL VECTOR
		    	if(cad != null) {
		    		CodigoComp =  CodigoComp + cad;	
		    		//System.out.println(CodigoComp);
		    	}
		    }	
			
			//*****************************************************************************************
		    CodigoComp = eliminaComas(CodigoComp);   // AL CODIGO COMPLETO LE QUITAMOS COMAS 
		    CodigoComp = eliminaPuntos(CodigoComp);	 // AL CODIGO COMPLETO LE QUITAMOS PUNTOS 
		   
		    CodigoComp = CodigoComp.replaceAll("( )+", " ");
		    
		    bandera = respaldarNuevoArchivo(CodigoComp); 
		    if(bandera == false) {
		    	JOptionPane.showMessageDialog(null, "El codigo no se limpio");
		    } 
		    eliminarComentariosIncio(rutanueva);     // AL CODIGO DEL ARCHIVO .TXT LE QUITAMOS COMENTARIOS   
	// *****************************************************************************************	        
	       
		    codeSeparado = SeparaTodo(rutanueva); 	// CADENA SEPARADA	   
		    
		    bandera = respaldaArchSeparado(codeSeparado);  // GUARDA EN UN TXT LA CADENA SEPARADA
	        if(bandera == false) {
		    	JOptionPane.showMessageDialog(null, "El codigo no se guardo");
		    }
	        
	       
	        lineas = null;
		    CodigoComp = null;
		    codeSeparado = null;  
	}
	

	 public int totLineasSeparadas() {	
		return cont;
	  } 
	
	 //METODO QUE ELIMINA COMAS
   public String eliminaComas(String cadena){
   String aux=""; int i=0,b=0,tam=cadena.length(); 
   if(!cadena.equals("")){
   do{
  
        if((cadena.charAt(i)==',')){             
           b=1;
        aux=aux+" ";
        } 
        
        if(b<1){
        aux=aux+cadena.charAt(i);
        }
        b=0;
        i++;
        
    }while((b!=2)&&(i<tam));
   }else{
   aux=null;
   }
   	return aux;
	}
   
 //ELIMINA DOS PUNTOS
   public String eliminaPuntos(String cadena){
   String aux=""; int i=0,b=0,tam=cadena.length(); 
   if(!cadena.equals("")){
   do{
        if((cadena.charAt(i)==':')){             
           b=1;
        aux=aux+" ";
       
        } 
       
        if(b<1){
        aux=aux+cadena.charAt(i);
        }
        b=0;
        
        i++;
        
    }while((b!=2)&&(i<tam));
   
   }else{
   aux=null;
   
   }
   	return aux;
   }
	
   
	// METE EL CODIGO EN UN ARCHIVO DE TEXTO
	   public boolean respaldarNuevoArchivo(String datos){
	       Formatter archivo = null;
	       boolean bandera = false;	   
	       try {
	           archivo = new Formatter(rutanueva);
	           archivo.format("%s", datos);
	           bandera = true;          
	       } catch (Exception e) {
	           System.out.println("Ha ocurrido un  error:"+e.toString());
	       }
	       archivo.close();	            
	       return bandera;
	   }
	   
	 //PROCESO ELIMINAR COMENTARIOS DE INICIO
	    public void eliminarComentariosIncio(String ruta){
	        String aux="";
	        try{
	            FileReader fr =  new FileReader(ruta);
	            BufferedReader br = new BufferedReader(fr);
	            String lineaLeida = "";	            
	            while(((lineaLeida=br.readLine())!=null)){	                
	                if(!lineaLeida.equals("")){
	                aux = aux + "\n"+ eliminarComentarios(lineaLeida);    //YA
	                }	                
	            }  
	                respaldarNuevoArchivo(aux); //YA
	                respaldarNuevoArchivo(EliminarEspacios(rutanueva,1));//YA
	                borrarEspaciosBlanco(rutanueva); //YA                
	                fr.close();
	                br.close();	                
	        }catch (Exception e) {
	            System.out.println("Ocurrio un error en el proceso de separado");
	        }	        
	    }
	    
	    
	
	   //ELIMINA COMENTARIOS
	    public String eliminarComentarios(String cade){
	      String aux=""; int b=0,i=0,tam=cade.length();
	        if(!cade.equals("")){
	          do{
	             if(cade.charAt(i)!=';'){
	             aux=aux+cade.charAt(i);
	             }else{
	             b=1;
	             }
	             i++;
	          }while((b!=1)&&(i<tam));    
	    }
	    return aux;
	    }
	    
	    
	  //Elimina lineas completas en blanco del archivo  
	    public String EliminarEspacios(String cadena,int n){
	     String aux=""; int i=0; 
	     try {
	          FileReader fr  = new FileReader(cadena);
	          BufferedReader br = new BufferedReader(fr);
	          String lineaLeida;	          
	          while(((lineaLeida=br.readLine())!=null)){
	      
	              if(n==1){
	                 if(!lineaLeida.equals("")){
	                	 if(i==0){
	                		 aux=lineaLeida; 
	                	 }else{
	                		 aux=aux+"\n"+lineaLeida; 
	                	 }
	                	 	i++;
	                 	 }    
	              }else{	                   
	                  if(!lineaLeida.equals("    ")&&!lineaLeida.equals("   ")&&!lineaLeida.equals("")){
	                   if(i==0){
	                        aux=lineaLeida; 
	                   }else{
	                        if(!lineaLeida.equals("           ")){ 
	                            aux=aux+"\n"+lineaLeida;    
	                        }	                       
	                   }
	                        i++;     
	                   }
	              }	              
	          }	
	          
	          fr.close();
	          br.close();
	     } catch (Exception e) {
	        System.out.println("Ocurrio un error en ordenar el archivo");
	        }    
	     return aux;
	    }    
	    
	  //Borramos los espacios al inicio de la linea  
		   public void borrarEspaciosBlanco(String ruta){
		       String aux="",a; int i=0;
		       try {
		             FileReader fr =  new FileReader(ruta);
		             BufferedReader br = new BufferedReader(fr);
		             String lineaLeida = "";
		             
		             while(((lineaLeida=br.readLine())!=null)){
		                 a=EliminarEspacion(lineaLeida);
		                 if(i==0){
		                     aux=a;
		                 }else{
		                     aux=aux+"\n"+a;
		                 }
		                 i++;
		             }
		             respaldarNuevoArchivo(aux);
		             
		             fr.close();
		             br.close();
		             
		       } catch (Exception e) {
		       }
		   }
		    
	    
	    
	    //BORRAR LOS ESPACIOS INICIALES SOLO SI HAY
		   public String EliminarEspacion(String cad){
		       String nuevaCad=""; int j=-8,i=0,b=0;
		       do{           
		        if((cad.charAt(i)=='	')||(cad.charAt(i)==' ')||(cad.charAt(i)==' ')||(cad.charAt(i)==' ')){
		          if(j<i){
		            while((cad.charAt(i)=='	')||(cad.charAt(i)==' ')||(cad.charAt(i)==' ')||(cad.charAt(i)==' ')){
		                i++;
		                if(i==cad.length()){
		                    break;
		                }
		            }
		            
		            while(i<cad.length()){
		                nuevaCad=nuevaCad+cad.charAt(i);
		                j=i;
		                i++;
		            }  
		          }   
		         }else{
		            b=1;
		            nuevaCad=cad;
		        }
		        i++;
		       }while((i<cad.length())&&(b==0));
		       return nuevaCad;
		   }
		   
		   
		   
	
		    
		    public boolean respaldaArchSeparado(String cadena){
				   Formatter archivo = null;
				   boolean bandera = false;
				       try {
				           archivo= new Formatter(ArchSeparado);
				           archivo.format("%s", cadena);
				           bandera = true;
				       } catch (Exception e) {
				           System.out.println("Ha ocurrido un  error:"+e.toString());
				       }
				       archivo.close();
				       
				       return bandera;
			   }
		

		
		public String SeparaTodo(String ruta) {
			   String cad = "";
			   ArrayList<String> lista = new ArrayList<String>();		   
			   try {
				   FileReader arch = new FileReader(ruta);
				   BufferedReader br = new BufferedReader(arch);
				   String linea="";			   
				   while((linea = br.readLine()) != null) { 				//PSEUDOINSTRUCCIONES

					   if(linea.toUpperCase().equals("DATA SEGMENT")) {
						   lista.add(linea);
					   }else if(linea.toUpperCase().equals("STACK SEGMENT")) {
						   lista.add(linea);
					   }else if(linea.toUpperCase().equals("CODE SEGMENT")) {
						   lista.add(linea);
					   }else if(linea.toUpperCase().equals("BYTE PTR")) {
						   lista.add(linea);
					   }else if(linea.toUpperCase().equals("WORD PTR")) {
						   lista.add(linea);
					   }else if(linea.toUpperCase().equals("BYTE PTR")) {
						   lista.add(linea);
					   }else {
						  String[] aux = linea.split("\\s+");
						  String cad2="";
						  for(int i=0; i<aux.length; i++) {
							  if(aux[i].matches("^\".*")) {
								  cad2 = cad2 + aux[i];
								  if(aux[i].matches(".*\"$")) {
									//  System.out.println(aux[i]);
								  }else {
									  i++;
									  while(aux[i].matches(".*[^\"$]")) {
										  cad2 = cad2 + " " + aux[i];
										  i++;
									  }
									  cad2 = cad2 + " " + aux[i];
									  lista.add(cad2);
								  }
							  }else {
								  if(aux[i].matches("\\s+")) {
									  JOptionPane.showMessageDialog(null, "Espacio en blanco");
								  }else {
									  lista.add(aux[i]);
								  }
							  }
						  }
					  				  
					   }			   
				   }			   
				   for(String dato : lista) {
					   cad = cad + dato + "\n";
					   cont = cont +1;
				   }
				   arch.close();
				   br.close();	   
			   }catch(Exception e){
				   	 JOptionPane.showMessageDialog(null, "Error" + e.getMessage());
			   }	   
			   return cad;
		   }
		 
	
		
}
