# Design Guidelines: Analizador Léxico de Ensamblador - Equipo 2

## Design Approach

**Selected Approach:** Design System Approach (VS Code + Linear inspired)

**Justification:** This is a utility-focused developer tool requiring maximum readability, efficient information display, and familiar IDE-like patterns. The application prioritizes function over form, with clean data presentation and code analysis workflows.

**Key Design Principles:**
- **Code-first clarity:** Monospace typography and syntax-aware layouts
- **Information density:** Efficient use of space for large datasets
- **Split-panel efficiency:** Simultaneous view of source and analysis
- **Familiar patterns:** Developer-friendly interface matching code editor conventions

---

## Typography

**Font Families:**
- **Monospace (Code/Data):** `'JetBrains Mono', 'Fira Code', 'Consolas', monospace`
- **Sans-serif (UI):** `'Inter', 'system-ui', sans-serif`

**Hierarchy:**
- **Main Title:** Sans-serif, text-xl (20px), font-semibold
- **Section Headers:** Sans-serif, text-base (16px), font-medium
- **Code Content:** Monospace, text-sm (14px), font-normal
- **Table Headers:** Sans-serif, text-sm (14px), font-semibold, uppercase tracking-wide
- **Table Data:** Monospace, text-sm (14px), font-normal
- **Stats/Labels:** Sans-serif, text-xs (12px), font-medium
- **Button Text:** Sans-serif, text-sm (14px), font-medium

**Line Heights:**
- Code blocks: `leading-6` (1.5)
- UI text: `leading-normal` (1.5)
- Table rows: `leading-tight` (1.25)

---

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8, 12, 16**

**Common Applications:**
- Component padding: `p-4`, `p-6`
- Section gaps: `gap-4`, `gap-6`
- Margins between elements: `mb-4`, `mt-6`
- Button padding: `px-4 py-2`, `px-6 py-3`
- Input padding: `px-4 py-2`
- Table cell padding: `px-4 py-2`

**Grid Structure:**
- Main container: `max-w-7xl mx-auto px-4`
- Split panels: 50/50 or 40/60 responsive grid
- Table layouts: Full-width with horizontal scroll

**Vertical Rhythm:**
- Consistent `space-y-4` or `space-y-6` between major sections
- `gap-2` between related form elements
- `gap-4` between unrelated components

---

## Component Library

### Core UI Elements

**File Upload Section**
- Horizontal layout with label, input field, and button
- Input: Full-width with border, rounded corners, monospace font for filepath
- Button: Solid style, `px-6 py-2`, rounded, medium font weight
- Browse icon optional, text-based is sufficient

**Action Buttons**
- Primary: Solid background, `px-6 py-3`, rounded-md
- Secondary: Border style, same padding
- Icon buttons (prev/next): Square 40x40, centered icon, rounded

### Navigation

**Top Bar**
- Fixed or sticky header, full-width
- Horizontal flex layout: title left, actions right
- Height: `h-16` with centered content
- Contains: App title, file selection controls, analysis button

**Pagination Controls**
- Centered horizontal layout
- Components: Previous button | Page indicator (text) | Next button | Total count
- Spacing: `gap-4` between elements
- Page indicator: Text format "Página X de Y"

### Forms

**File Input Group**
- Label above or inline-left
- Input field with border, `px-4 py-2`, rounded
- Browse button adjacent
- Selected filepath display below or inline

### Data Displays

**Code Viewer (Left Panel)**
- Full-height scrollable area
- Monospace font throughout
- Line numbers in left gutter (optional, adds clarity)
- Bordered container with subtle inset appearance
- Horizontal and vertical scroll enabled
- Background distinguishes from table area

**Elements Table (Right Panel)**
- Three columns: "Número", "Elemento", "Clasificación"
- Column widths: Auto (number) | Flex (element) | Flex (classification)
- Header row: Sticky top, distinct background, uppercase labels
- Data rows: Alternating row background for readability
- Monospace for "Elemento" column, sans-serif for classification
- Full vertical scroll with fixed header
- Horizontal scroll if needed for long elements

**Statistics Bar**
- Full-width horizontal layout below table
- Displays: Total elementos | By category counts
- Format: "Total: X | Instrucciones: Y | Registros: Z..."
- Small font size, medium weight
- Fixed to bottom of panel or floating above pagination

### Overlays

**Error/Success Messages**
- Toast notifications: top-right corner
- Alert boxes: Centered modal for critical errors
- Inline validation: Below relevant input field
- Auto-dismiss after 5 seconds for non-critical

---

## Layout Specifications

**Main Application Structure**

```
┌─────────────────────────────────────────────────┐
│  Header (File controls + Analyze button)       │ h-16
├─────────────────┬───────────────────────────────┤
│                 │                               │
│  Source Code    │  Elements Table               │
│  (Scrollable)   │  (Scrollable)                 │
│                 │                               │
│  50% width      │  50% width                    │
│                 │                               │
│                 ├───────────────────────────────┤
│                 │  Statistics Bar               │ h-12
├─────────────────┴───────────────────────────────┤
│  Pagination Controls (centered)                 │ h-16
└─────────────────────────────────────────────────┘
```

**Responsive Behavior:**
- Desktop (≥1024px): Side-by-side panels
- Tablet (768-1023px): Stacked panels with tabs or accordion
- Mobile (<768px): Single column, tabbed navigation between views

**Component Spacing:**
- Header to content: `pt-6`
- Panel internal padding: `p-6`
- Between panels: `gap-6`
- Table cells: `px-4 py-2`

---

## Specific Component Details

**Header Navigation:**
- Flex container with `justify-between`
- App title: `text-xl font-semibold`
- File controls group: Flex row with `gap-4`
- Analyze button: Prominent, primary style

**Split Panel Container:**
- Grid or flex with equal distribution
- Vertical divider between panels (1px border)
- Both panels independently scrollable
- Min-height to fill viewport minus header/footer

**Pagination Footer:**
- Centered flex container
- Button states: Disabled when at boundaries
- Clear visual hierarchy: buttons > text indicators
- Responsive: Stack on mobile if needed

**Table Header:**
- Sticky positioning: `sticky top-0`
- Higher z-index than rows
- Distinct background with slight shadow or border
- Text transformation: Uppercase with letter spacing

**Table Rows:**
- Hover state for interactivity
- Consistent padding: `px-4 py-2`
- Border between rows: subtle 1px
- Alternating backgrounds: nth-child pattern

**Statistics Display:**
- Horizontal flex with `gap-6`
- Each stat: Label + value pair
- Separator between stats: Vertical divider or bullet
- Sticky or fixed at bottom of table container

---

## Animations

**Minimal, Purposeful Motion Only:**
- Fade-in for error/success messages: 200ms ease
- Smooth scroll when changing pages: 300ms ease
- No transitions on table rows or interactive elements
- Loading spinner during file processing: Simple rotation

---

## Images

**No images required** - This is a pure utility application focused on code analysis. All visual interest comes from typography, layout, and data presentation.