import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { LexicalAnalyzer } from "./lexical-analyzer";
import { analyzeFileRequestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const analyzer = new LexicalAnalyzer();

  // POST /api/analyze - Analizar archivo
  app.post("/api/analyze", async (req, res) => {
    try {
      // Validar request
      const parseResult = analyzeFileRequestSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({
          error: "Datos inválidos",
          details: parseResult.error.errors,
        });
      }

      const { filename, content } = parseResult.data;

      // Realizar análisis léxico
      const result = analyzer.analyze(content);

      // Guardar resultado en memoria
      const analysisResult = {
        filename,
        originalContent: content,
        ...result,
      };

      await storage.saveAnalysis(analysisResult);

      // Retornar resultado
      res.json(analysisResult);
    } catch (error) {
      console.error("Error en análisis:", error);
      res.status(500).json({
        error: "Error al procesar el archivo",
        message: error instanceof Error ? error.message : "Error desconocido",
      });
    }
  });

  // GET /api/analyses - Obtener todos los análisis
  app.get("/api/analyses", async (_req, res) => {
    try {
      const analyses = await storage.getAllAnalyses();
      res.json(analyses);
    } catch (error) {
      console.error("Error al obtener análisis:", error);
      res.status(500).json({
        error: "Error al obtener los análisis",
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
