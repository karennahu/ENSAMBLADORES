import type { AnalysisResult } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  saveAnalysis(analysis: AnalysisResult): Promise<string>;
  getAnalysis(id: string): Promise<AnalysisResult | undefined>;
  getAllAnalyses(): Promise<AnalysisResult[]>;
}

export class MemStorage implements IStorage {
  private analyses: Map<string, AnalysisResult & { id: string }>;

  constructor() {
    this.analyses = new Map();
  }

  async saveAnalysis(analysis: AnalysisResult): Promise<string> {
    const id = randomUUID();
    this.analyses.set(id, { ...analysis, id });
    return id;
  }

  async getAnalysis(id: string): Promise<AnalysisResult | undefined> {
    return this.analyses.get(id);
  }

  async getAllAnalyses(): Promise<AnalysisResult[]> {
    return Array.from(this.analyses.values());
  }
}

export const storage = new MemStorage();
