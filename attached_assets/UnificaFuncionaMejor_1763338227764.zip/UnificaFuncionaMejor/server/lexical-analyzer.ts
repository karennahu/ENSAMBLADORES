import type { AnalyzedElement } from "@shared/schema";

// Instrucciones del Equipo 2
const TEAM_2_INSTRUCTIONS = new Set([
  "CMC", "CMPSB", "NOP", "POPA", "AAD", "AAM", "MUL", "INC", 
  "IDIV", "INT", "AND", "LEA", "OR", "XOR", "JNAE", "JNE", 
  "JNLE", "LOOPE", "JA", "JC"
]);

// Pseudoinstrucciones
const PSEUDOINSTRUCTIONS = new Set([
  ".CODE SEGMENT", ".DATA SEGMENT", ".STACK SEGMENT",
  "DATA SEGMENT", "CODE SEGMENT", "STACK SEGMENT",
  "BYTE PTR", "WORD PTR",
  "SEGMENT", "ENDS", "END",
  "DB", "DW", "DD", "DQ", "DT",
  "EQU", "MACRO", "ENDM", "PROC", "ENDP",
  "ASSUME", "ORG"
]);

// Registros
const REGISTERS = new Set([
  // Registros de 16 bits generales
  "AX", "BX", "CX", "DX",
  // Registros de 8 bits
  "AH", "AL", "BH", "BL", "CH", "CL", "DH", "DL",
  // Registros de índice y punteros
  "SI", "DI", "BP", "SP",
  // Registros de segmento
  "CS", "DS", "ES", "SS",
  // Registros especiales
  "IP", "FLAGS"
]);

export class LexicalAnalyzer {
  private elementCounter = 0;

  analyze(content: string): {
    cleanedContent: string;
    elements: AnalyzedElement[];
    statistics: {
      total: number;
      instrucciones: number;
      pseudoinstrucciones: number;
      registros: number;
      simbolos: number;
      constantesDecimal: number;
      constantesHexadecimal: number;
      constantesBinaria: number;
      constantesCaracter: number;
    };
  } {
    // 1. Eliminar comentarios
    const cleanedContent = this.removeComments(content);

    // 2. Extraer elementos
    const rawElements = this.extractElements(cleanedContent);

    // 3. Identificar elementos
    const elements = rawElements.map((element, index) => ({
      number: index + 1,
      element: element,
      classification: this.classifyElement(element),
    }));

    // 4. Calcular estadísticas
    const statistics = this.calculateStatistics(elements);

    return {
      cleanedContent,
      elements,
      statistics,
    };
  }

  private removeComments(content: string): string {
    const lines = content.split("\n");
    const cleanedLines = lines.map(line => {
      const commentIndex = line.indexOf(";");
      if (commentIndex !== -1) {
        return line.substring(0, commentIndex);
      }
      return line;
    });
    return cleanedLines.join("\n");
  }

  private extractElements(content: string): string[] {
    const elements: string[] = [];
    
    // Mapa de placeholders a valores reales
    const compoundMap = new Map<string, string>();
    let placeholderCounter = 0;

    // Función helper para crear placeholder único
    const createPlaceholder = (value: string): string => {
      const placeholder = `__PLACEHOLDER_${placeholderCounter}__`;
      compoundMap.set(placeholder, value);
      placeholderCounter++;
      return placeholder;
    };

    let processedContent = content;

    // 1. Proteger elementos compuestos de múltiples palabras (ANTES del split)
    const multiWordCompounds = [
      ".CODE SEGMENT", ".DATA SEGMENT", ".STACK SEGMENT",
      "DATA SEGMENT", "CODE SEGMENT", "STACK SEGMENT",
      "BYTE PTR", "WORD PTR"
    ];

    for (const compound of multiWordCompounds) {
      const regex = new RegExp(compound.replace(/\s+/g, "\\s+"), "gi");
      processedContent = processedContent.replace(regex, (match) => createPlaceholder(match));
    }

    // 2. Proteger cadenas entre comillas
    const stringRegex = /(['"])(?:(?=(\\?))\2.)*?\1/g;
    processedContent = processedContent.replace(stringRegex, (match) => createPlaceholder(match));

    // 3. Proteger expresiones DUP(...)
    const dupRegex = /DUP\s*\([^)]*\)/gi;
    processedContent = processedContent.replace(dupRegex, (match) => createPlaceholder(match));

    // 4. Proteger expresiones entre corchetes [...]
    const bracketRegex = /\[[^\]]*\]/g;
    processedContent = processedContent.replace(bracketRegex, (match) => createPlaceholder(match));

    // 5. Separar por espacio, coma y dos puntos
    const tokens = processedContent.split(/[\s,:]+/);

    // 6. Restaurar placeholders y construir lista de elementos
    for (const token of tokens) {
      if (!token || token.trim() === "") continue;

      // Si es un placeholder, restaurar el valor original
      const originalValue = compoundMap.get(token);
      if (originalValue) {
        elements.push(originalValue);
      } else {
        elements.push(token);
      }
    }

    return elements;
  }

  private classifyElement(element: string): string {
    const upperElement = element.toUpperCase();

    // 1. Instrucciones del Equipo 2
    if (TEAM_2_INSTRUCTIONS.has(upperElement)) {
      return "Instrucción";
    }

    // 2. Pseudoinstrucciones
    if (PSEUDOINSTRUCTIONS.has(upperElement)) {
      return "Pseudoinstrucción";
    }

    // 3. Registros
    if (REGISTERS.has(upperElement)) {
      return "Registro";
    }

    // 4. Constantes de carácter (entre comillas)
    if ((element.startsWith('"') && element.endsWith('"')) ||
        (element.startsWith("'") && element.endsWith("'"))) {
      return "Constante carácter";
    }

    // 5. Elementos compuestos especiales
    if (element.startsWith("[") && element.endsWith("]")) {
      return "Dirección de memoria";
    }

    if (upperElement.startsWith("DUP(") || upperElement.includes("DUP(")) {
      return "Expresión DUP";
    }

    // 6. Constantes numéricas hexadecimales
    if (/^[0-9A-F]+H$/i.test(element) || /^0x[0-9A-F]+$/i.test(element)) {
      return "Constante numérica hexadecimal";
    }

    // 7. Constantes numéricas binarias
    if (/^[01]+B$/i.test(element)) {
      return "Constante numérica binaria";
    }

    // 8. Constantes numéricas decimales
    if (/^\d+$/.test(element)) {
      return "Constante numérica decimal";
    }

    // 9. Símbolos (identificadores válidos)
    if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(element)) {
      return "Símbolo";
    }

    // 10. Elemento no identificado
    return "Elemento no identificado";
  }

  private calculateStatistics(elements: AnalyzedElement[]) {
    const stats = {
      total: elements.length,
      instrucciones: 0,
      pseudoinstrucciones: 0,
      registros: 0,
      simbolos: 0,
      constantesDecimal: 0,
      constantesHexadecimal: 0,
      constantesBinaria: 0,
      constantesCaracter: 0,
    };

    for (const element of elements) {
      switch (element.classification) {
        case "Instrucción":
          stats.instrucciones++;
          break;
        case "Pseudoinstrucción":
          stats.pseudoinstrucciones++;
          break;
        case "Registro":
          stats.registros++;
          break;
        case "Símbolo":
          stats.simbolos++;
          break;
        case "Constante numérica decimal":
          stats.constantesDecimal++;
          break;
        case "Constante numérica hexadecimal":
          stats.constantesHexadecimal++;
          break;
        case "Constante numérica binaria":
          stats.constantesBinaria++;
          break;
        case "Constante carácter":
          stats.constantesCaracter++;
          break;
      }
    }

    return stats;
  }
}
