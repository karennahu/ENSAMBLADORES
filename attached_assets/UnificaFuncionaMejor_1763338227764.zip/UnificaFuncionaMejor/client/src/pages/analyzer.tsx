import { useState } from "react";
import { FileUploader } from "@/components/file-uploader";
import { CodeViewer } from "@/components/code-viewer";
import { ElementsTable } from "@/components/elements-table";
import { Statistics } from "@/components/statistics";
import { Pagination } from "@/components/pagination";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileCode2, Trash2 } from "lucide-react";
import type { AnalysisResult } from "@shared/schema";

const ELEMENTS_PER_PAGE = 20;

export default function Analyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    setAnalysisResult(null);
    setCurrentPage(1);
  };

  const handleAnalyze = async () => {
    if (!file) {
      toast({
        title: "Error",
        description: "Por favor selecciona un archivo primero",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      const content = await file.text();
      
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          filename: file.name,
          content: content,
        }),
      });

      if (!response.ok) {
        throw new Error("Error al analizar el archivo");
      }

      const result: AnalysisResult = await response.json();
      setAnalysisResult(result);
      setCurrentPage(1);

      toast({
        title: "Análisis Completado",
        description: `Se encontraron ${result.elements.length} elementos`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al analizar el archivo",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleClear = () => {
    setFile(null);
    setAnalysisResult(null);
    setCurrentPage(1);
  };

  const totalPages = analysisResult
    ? Math.ceil(analysisResult.elements.length / ELEMENTS_PER_PAGE)
    : 0;

  const paginatedElements = analysisResult
    ? analysisResult.elements.slice(
        (currentPage - 1) * ELEMENTS_PER_PAGE,
        currentPage * ELEMENTS_PER_PAGE
      )
    : [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
          <div className="flex items-center gap-3">
            <FileCode2 className="h-6 w-6 text-primary" data-testid="icon-logo" />
            <div>
              <h1 className="text-xl font-semibold" data-testid="text-title">
                Analizador Léxico 8086
              </h1>
              <p className="text-xs text-muted-foreground">Equipo 2 - Fase 1</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Button
              onClick={handleAnalyze}
              disabled={!file || isAnalyzing}
              data-testid="button-analyze"
            >
              <Upload className="mr-2 h-4 w-4" />
              {isAnalyzing ? "Analizando..." : "Analizar"}
            </Button>

            {file && (
              <Button
                variant="outline"
                onClick={handleClear}
                data-testid="button-clear"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Limpiar
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto max-w-7xl px-4 py-6">
        {/* Show results if we have analysis */}
        {analysisResult ? (
          <div className="space-y-6">
            <FileUploader onFileSelect={handleFileSelect} initialFile={file} />

            {/* Statistics */}
            <Statistics statistics={analysisResult.statistics} />

            {/* Dual Code Viewers: Original vs Cleaned */}
            <div className="grid gap-6 lg:grid-cols-2">
              <CodeViewer
                title="Código Original"
                content={analysisResult.originalContent}
                filename={analysisResult.filename}
              />
              
              <CodeViewer
                title="Código sin Comentarios"
                content={analysisResult.cleanedContent}
                filename={`${analysisResult.filename} (limpio)`}
              />
            </div>

            {/* Elements Table and Pagination */}
            <div className="space-y-4">
              <ElementsTable
                elements={paginatedElements}
                currentPage={currentPage}
                elementsPerPage={ELEMENTS_PER_PAGE}
              />

              {totalPages > 1 && (
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  totalElements={analysisResult.elements.length}
                  onPageChange={setCurrentPage}
                />
              )}
            </div>
          </div>
        ) : file ? (
          /* Show file loaded state */
          <div className="space-y-6">
            <FileUploader onFileSelect={handleFileSelect} initialFile={file} />
            
            <div className="grid gap-6 lg:grid-cols-2">
              <CodeViewer
                title="Archivo Cargado"
                content="Presiona 'Analizar' para procesar el archivo"
                filename={file.name}
              />
              <div className="flex items-center justify-center border rounded-md bg-card p-12">
                <div className="text-center text-muted-foreground">
                  <FileCode2 className="mx-auto h-12 w-12 mb-4 opacity-50" />
                  <p className="text-sm">Elementos aparecerán aquí después del análisis</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Show initial upload state */
          <div className="flex items-center justify-center py-12">
            <FileUploader onFileSelect={handleFileSelect} />
          </div>
        )}
      </main>
    </div>
  );
}
