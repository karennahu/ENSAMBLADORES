import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

interface CodeViewerProps {
  title: string;
  content: string;
  filename: string;
}

export function CodeViewer({ title, content, filename }: CodeViewerProps) {
  const lines = content.split("\n");

  return (
    <Card className="flex flex-col h-[600px]">
      <div className="border-b p-4">
        <h3 className="text-base font-semibold">{title}</h3>
        {filename && (
          <p className="text-xs text-muted-foreground font-mono mt-1" data-testid="text-code-filename">
            {filename}
          </p>
        )}
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4">
          <pre className="font-mono text-sm leading-6">
            {lines.map((line, index) => (
              <div key={index} className="flex" data-testid={`line-${index + 1}`}>
                <span className="inline-block w-12 text-right pr-4 text-muted-foreground select-none">
                  {index + 1}
                </span>
                <span className="flex-1">{line || " "}</span>
              </div>
            ))}
          </pre>
        </div>
      </ScrollArea>
    </Card>
  );
}
