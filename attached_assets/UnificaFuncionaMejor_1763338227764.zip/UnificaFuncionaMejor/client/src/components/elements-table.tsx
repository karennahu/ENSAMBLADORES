import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { AnalyzedElement } from "@shared/schema";

interface ElementsTableProps {
  elements: AnalyzedElement[];
  currentPage: number;
  elementsPerPage: number;
}

export function ElementsTable({ elements, currentPage, elementsPerPage }: ElementsTableProps) {
  const startIndex = (currentPage - 1) * elementsPerPage;

  return (
    <Card className="flex flex-col h-[600px]">
      <div className="border-b p-4">
        <h3 className="text-base font-semibold">Elementos Identificados</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Análisis lexicográfico completo
        </p>
      </div>

      <div className="border-b bg-muted/50 px-4 py-2">
        <div className="grid grid-cols-12 gap-4 text-xs font-semibold uppercase tracking-wide">
          <div className="col-span-2">Número</div>
          <div className="col-span-5">Elemento</div>
          <div className="col-span-5">Clasificación</div>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="divide-y">
          {elements.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              <p className="text-sm">No hay elementos para mostrar</p>
            </div>
          ) : (
            elements.map((element) => (
              <div
                key={element.number}
                className="grid grid-cols-12 gap-4 px-4 py-2 text-sm hover-elevate"
                data-testid={`element-${element.number}`}
              >
                <div className="col-span-2 font-mono text-muted-foreground">
                  {element.number}
                </div>
                <div className="col-span-5 font-mono font-medium">
                  {element.element}
                </div>
                <div className="col-span-5 text-muted-foreground">
                  {element.classification}
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
