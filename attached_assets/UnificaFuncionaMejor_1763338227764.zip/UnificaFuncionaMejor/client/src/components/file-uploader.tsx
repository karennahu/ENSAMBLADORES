import { useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, File } from "lucide-react";

interface FileUploaderProps {
  onFileSelect: (file: File) => void;
  initialFile?: File | null;
}

export function FileUploader({ onFileSelect, initialFile }: FileUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleClick = () => {
    inputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Selección de Archivo</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Cualquier tipo de archivo (.*) - Código ensamblador 8086
            </p>
          </div>
          <Button onClick={handleClick} data-testid="button-browse">
            <Upload className="mr-2 h-4 w-4" />
            Buscar
          </Button>
        </div>

        <input
          ref={inputRef}
          type="file"
          className="hidden"
          onChange={handleFileChange}
          accept="*"
          data-testid="input-file"
        />

        {initialFile && (
          <div className="flex items-center gap-3 p-4 rounded-md bg-muted/50 border">
            <File className="h-5 w-5 text-primary" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium font-mono truncate" data-testid="text-filename">
                {initialFile.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {(initialFile.size / 1024).toFixed(2)} KB
              </p>
            </div>
          </div>
        )}

        {!initialFile && (
          <div className="border-2 border-dashed rounded-md p-12 text-center hover-elevate cursor-pointer" onClick={handleClick}>
            <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-sm font-medium mb-1">
              Haz clic para seleccionar un archivo
            </p>
            <p className="text-xs text-muted-foreground">
              .asm, .fte, .txt o cualquier archivo de código
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}
