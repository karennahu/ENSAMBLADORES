import { Card } from "@/components/ui/card";
import type { AnalysisResult } from "@shared/schema";

interface StatisticsProps {
  statistics: AnalysisResult["statistics"];
}

export function Statistics({ statistics }: StatisticsProps) {
  const stats = [
    { label: "Total", value: statistics.total, color: "text-primary" },
    { label: "Instrucciones", value: statistics.instrucciones, color: "text-chart-1" },
    { label: "Pseudoinstrucciones", value: statistics.pseudoinstrucciones, color: "text-chart-2" },
    { label: "Registros", value: statistics.registros, color: "text-chart-3" },
    { label: "Símbolos", value: statistics.simbolos, color: "text-chart-4" },
    { label: "Const. Decimal", value: statistics.constantesDecimal, color: "text-muted-foreground" },
    { label: "Const. Hexadecimal", value: statistics.constantesHexadecimal, color: "text-muted-foreground" },
    { label: "Const. Binaria", value: statistics.constantesBinaria, color: "text-muted-foreground" },
    { label: "Const. Carácter", value: statistics.constantesCaracter, color: "text-muted-foreground" },
  ];

  return (
    <Card className="p-6">
      <h2 className="text-base font-semibold mb-4">Estadísticas del Análisis</h2>
      
      <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
            <p className={`text-2xl font-semibold font-mono ${stat.color}`}>
              {stat.value}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {stat.label}
            </p>
          </div>
        ))}
      </div>
    </Card>
  );
}
