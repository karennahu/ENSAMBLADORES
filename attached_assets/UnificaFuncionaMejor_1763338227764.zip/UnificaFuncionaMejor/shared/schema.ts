import { z } from "zod";

// Elemento analizado del código fuente
export const analyzedElementSchema = z.object({
  number: z.number(),
  element: z.string(),
  classification: z.string(),
});

export type AnalyzedElement = z.infer<typeof analyzedElementSchema>;

// Resultado del análisis
export const analysisResultSchema = z.object({
  filename: z.string(),
  originalContent: z.string(),
  cleanedContent: z.string(),
  elements: z.array(analyzedElementSchema),
  statistics: z.object({
    total: z.number(),
    instrucciones: z.number(),
    pseudoinstrucciones: z.number(),
    registros: z.number(),
    simbolos: z.number(),
    constantesDecimal: z.number(),
    constantesHexadecimal: z.number(),
    constantesBinaria: z.number(),
    constantesCaracter: z.number(),
  }),
});

export type AnalysisResult = z.infer<typeof analysisResultSchema>;

// Request para analizar archivo
export const analyzeFileRequestSchema = z.object({
  filename: z.string(),
  content: z.string(),
});

export type AnalyzeFileRequest = z.infer<typeof analyzeFileRequestSchema>;
